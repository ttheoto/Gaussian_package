# -*- coding: utf-8 -*-
"""
Created on Thu May  7 09:36:38 2020

@author: Tati
"""

from setuptools import setup

setup(name='test-theoto-distributions',
      version='0.1',
      description='Gaussian distributions',
      author = 'Tatiana Theoto',
      packages=['test-theoto-distributions'],
      zip_safe=False)
# -*- coding: utf-8 -*-
"""
Created on Thu May  7 09:27:59 2020

@author: Tati
"""


from .Gaussiandistribution import Gaussian
from .Binomialdistribution import Binomial